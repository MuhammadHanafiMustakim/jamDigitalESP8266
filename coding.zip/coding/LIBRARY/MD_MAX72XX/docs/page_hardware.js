var page_hardware =
[
    [ "Parola Custom Module", "page_parola.html", null ],
    [ "Generic Module", "page_generic.html", null ],
    [ "ICStation Module", "page_i_c_station.html", null ],
    [ "FC-16 Module", "page_f_c16.html", null ],
    [ "New Hardware Types", "page_new_hardware.html", null ]
];